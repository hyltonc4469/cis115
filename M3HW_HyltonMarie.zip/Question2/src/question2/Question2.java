/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question2;
import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Color;
import javax.swing.JFrame;
/**
 *
 * @author hyltonc4469
 */
public class Question2 extends Canvas {
    


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JFrame frame = new JFrame("My Drawing");
        Canvas canvas = new Question2();
        canvas.setSize(400, 400);
        frame.add(canvas);
        frame.pack();
        frame.setVisible(true);
      
    }
     public void paint(Graphics g) {
       // g.fillOval(100, 100, 200, 200);
	g.setColor(Color.red);
        g.drawLine(100,100,100,380);//left line
	g.drawLine(100,100,380,100);//top line
        g.drawLine(100,380,380,380);//bottom line
        g.drawLine(380,100,380,380);//right line
        
        //Draw a Triangle:
        g.drawLine(240,100,100,380);
        g.drawLine(240,100,380,380);
        g.drawLine(170,240,240,380);
        g.drawLine(240,380,310,240);
        g.drawLine(170,240,310,240);
        //g.drawLine(240,100,100,380);
        
        
}}
