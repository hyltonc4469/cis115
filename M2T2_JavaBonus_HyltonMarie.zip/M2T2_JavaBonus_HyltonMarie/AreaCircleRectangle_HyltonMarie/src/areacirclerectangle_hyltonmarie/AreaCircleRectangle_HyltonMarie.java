/**CIS 115
 *September 30, 2018
 * @author Marie
 * This program calculates the area of a rectangle and a circle.
 */

package areacirclerectangle_hyltonmarie;

//Import:
import javax.swing.JOptionPane;         //For the JOption Pane class.


public class AreaCircleRectangle_HyltonMarie {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // The rectangle's length, width, and area are declared.
        double length, width, areaRectangle;   
       //The circle's radius, pi, and area are declared.
      double radius, areaCircle, pi=3.14159265359;

      //Get the rectangle's length from the user.
      length = getLength();
      // Get the rectangle's width from the user.
      width = getWidth();
      // Get the rectangle's area.
      areaRectangle = getAreaRectangle(length, width);
      
      //Display the rectangle's data.
      displayRectangleData(length, width, areaRectangle);
      
      //Get the circle's radius from the user.
      radius=getRadius();
      
      //Get the circle's area.
      areaCircle=getAreaCircle(radius,pi);
      
      //Display the circle's data.
      displayCircleData(radius, pi, areaCircle);
      
      System.exit(0);
    }
    public static double getLength()
      {//User to enter the rectangle's length. Returns as a double.
      
       String input;        //To hold input.
       double length;       //To hold length.
       //Get the rectangle's length from the user.    
      input=JOptionPane.showInputDialog("Enter the rectangle's length: ");
      length=Double.parseDouble(input);
      //Return length
      return length;
      }
      
    public static double getWidth()
      {//User to enter the rectangle's width. Returns as a double.
      
      String input;             //To hold input.
      double width;             //To hold width.
      // Get the rectangle's width from the user.
      input=JOptionPane.showInputDialog("Enter the rectangle's width: ");
      width=Double.parseDouble(input);
      //Return width.
      return width;
      }
    public static double getRadius()
        {//User to enter the circle's radius.  Returns as a double.
            
         String input;       //To hold iput.
         double radius;       //To hold radius.
         //Get the circle's radius from the user.
         input=JOptionPane.showInputDialog("Enter the circle's radius: ");
         radius=Double.parseDouble(input);
         //Return radius.
         return radius;
        }
    
    
    public static double getAreaRectangle(double length,double width)
      {//Accept length and width.  Return the rectangle's area, lxw.
      double areaRectangle=length*width;    
      //Return the area.
      return areaRectangle;
      }
    
    
    public static double getAreaCircle(double radius,double pi)
    {//Accept radius and pi.  Return the circle's area, 2pir.
        double areaCircle=2*radius*pi;
        //Return the area.
        return areaCircle;
    }
    
    
    public static void displayRectangleData(double length, double width, 
            double areaRectangle)
      {//Accept the rectangle's length, width, and area.  Displays message.
      JOptionPane.showMessageDialog(null, "A rectangle with a length of "
              + length+ " and a width of " + width+ 
              " has an area of " + areaRectangle+".");    
    }
    
    
    public static void displayCircleData (double radius, double pi, 
            double areaCircle )
    {//Accept the circle's radius, pi, and area.  Displays Message.
        JOptionPane.showMessageDialog(null, "A circle with the radius of "
                + radius+ " and a pi estimate of "+ pi+ 
                " has an area of " + areaCircle+ ".");
    }
      }
      
    



      
