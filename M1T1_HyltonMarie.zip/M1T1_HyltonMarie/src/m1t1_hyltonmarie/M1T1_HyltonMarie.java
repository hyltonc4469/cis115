package m1t1_hyltonmarie;

/**
 *
 * @author hyltonc4469
 */

// M1T1
// Hello World
// Marie Hylton
// 08.22.18


public class M1T1_HyltonMarie {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
        // Print: Hello World.
        
        System.out.println("Hello, World!");
    }
    
}
