#CIS115
#Marie Hylton
#Oct. 22, 2018

'''This program creates a pumpkin using the turtle module'''

import turtle


t=turtle.Turtle() #Create turtle

def makeBody():
  '''makes the body for the pumpkin using a circle'''
  t.color('orange')
  t.begin_fill()
  t.circle(200)
  t.end_fill()

def makeEyes():
  '''makes the eyes for the pumpkin for triangle'''
  t.goto(0,0)
  t.goto(-100,200)
  t.color('black')
  t.begin_fill()
  for i in range(3):
    t.forward(60)
    t.left(120)
  t.end_fill()
  t.penup()
  t.goto(50,200)
  t.pendown()
  t.color('black')
  t.begin_fill()
  for i in range(3):
    t.forward(60)
    t.left(120)
  t.end_fill()

def makeMohawk():
  '''makes teh stem for the pumpkin using a square'''
  t.penup()
  t.goto(-50,400)
  t.pendown()
  t.color('brown')
  t.begin_fill()
  for i in range(4):
    t.forward(100)
    t.left(90)
  t.end_fill()

def makeSmile():
  '''makes the smile for the pumpkin using triangles'''
  t.penup()
  t.goto(-100,50)
  t.pendown()
  t.color('black')
  t.begin_fill()
  for i in range(4):
    t.forward(60)
    for i in range(3):
      t.left(120)
      t.forward(60)
  t.end_fill()






def main():
  '''runs the program using all the functions creates for each body part'''
  makeBody()
  makeEyes()
  makeMohawk()
  makeSmile()

main()
