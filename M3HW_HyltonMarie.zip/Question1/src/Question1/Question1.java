/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Question1;

import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Color;
import javax.swing.JFrame;



/**
 *
 * @author hyltonc4469
 */
public class Question1 extends Canvas{
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JFrame frame = new JFrame("My Drawing");
        Canvas canvas = new Question1();
        canvas.setSize(400, 400);
        frame.add(canvas);
        frame.pack();
        frame.setVisible(true);
       
    }
        public void paint(Graphics g) {
        g.fillOval(100, 100, 200, 200);
        
		g.setColor(Color.red);
		g.drawLine(100,100,100,380);
		g.drawLine(100,100,380,100);
                g.drawLine(100,380,380,380);//bottom line
                g.drawLine(380,100,380,380);//bottom left to top left
                
                
        
		
		
                
        }
}
