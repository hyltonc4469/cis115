#CIS 115
#Oct. 8
#Hylton Marie

'''This program creates three polygon shaped pies and retrieves the length of
each side from the user.  '''

import turtle

def main():
    t=turtle.Turtle()#Turtle
    menu(t)#Runs the menu

def drawPolygon(t, sides, size):
    '''draws the main polygon for each pie'''
    angle=360/sides#Var for angle of each side
    for side in range(sides):#Creates the main polygon
        t.forward(size)
        t.left(angle)
        
def menu(t):
    '''Runs the menu'''
    menu=print('1. Pentagon Pie\n2.Hexagon Pie\n3.Heptagon Pie')
    option=input("Choose an option.")
    size=int(input("What length do you want each side: "))
    #Decision structures for polygon shape options
    if option=='1':
        sides=int(5)
        drawPolygon(t, sides, size)
        drawPentPie(t, sides, size)
    elif option=='2':
        sides=int(6)
        drawPolygon(t, sides, size)
        drawHexPie(t, size, sides)
    elif option=='3':
        sides=int(7)
        drawPolygon(t, sides, size)
        drawHeptPie(t, size, sides)

     
    
        
def createTurtles():
    '''Creates multiple turtles'''
    j=turtle.Turtle()
    j.pencolor('red')
    k=turtle.Turtle()
    k.pencolor('blue')
    return j,k
    
def drawPentPie(t, sides, size):
    '''draws a pentagon pie'''
    triAngle=360/3
    j,k=createTurtles()

    t.forward(size)
    
    j.left(triAngle/2)
    j.forward(size)
    j.left(triAngle*(7/4))
    j.penup()
    j.forward(size)
    j.left(180)
    j.forward(size)
    j.pendown()
    j.forward(size)
    
    k.forward(size)
    k.left(triAngle)
    k.forward(size)
    k.right(triAngle)
    k.forward(size)
    k.penup()
    k.backward(size)
    k.right(180)
    k.pendown()
    k.forward(size)


def drawHexPie(t,size,sides):
    '''draws a hexagon pie'''
    j,k=createTurtles()
    triAngle=360/3
    
    j.left(triAngle/2)
    j.forward(size)
    j.forward(size)

    k.forward(size)
    k.left(triAngle)
    k.forward(size*2)
    k.backward(size)
    k.right(triAngle)
    k.forward(size)
    k.penup()
    k.backward(size)
    k.right(180)
    k.pendown()
    k.forward(size)

def drawHeptPie(t,size,sides):
    '''draws a heptagon pie'''
    triAngle=360/3
    j,k=createTurtles()

    t.forward(size)
    
    j.left(triAngle/2)
    j.forward(size*2)
    j.backward(size)
    j.left(triAngle*(7/4))
    j.penup()
    j.forward(size)
    j.left(180)
    j.forward(size)
    j.pendown()
    j.forward(size)
    
    k.forward(size)
    k.left(triAngle)
    k.forward(size)
    k.right(triAngle)
    k.forward(size)
    k.penup()
    k.backward(size)
    k.right(180)
    k.pendown()
    k.forward(size)
    k.backward(size)
    k.right(45)
    k.forward(size)



def drawTriangle(t, size,sides):
    '''draws the inner triangles that act as pie slices'''
    angle=360/3
    for i in range(3):
        
        t.backward(size)
        t.right(angle)
        
    
main()







