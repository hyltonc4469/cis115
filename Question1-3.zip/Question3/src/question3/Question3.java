/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question3;
import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Color;
import javax.swing.JFrame;

/**
 *
 * @author hyltonc4469
 */
public class Question3 extends Canvas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JFrame frame = new JFrame("My Drawing");
        Canvas canvas = new Question3();
        canvas.setSize(400, 400);
        frame.add(canvas);
        frame.pack();
        frame.setVisible(true);
    }
     public void paint(Graphics g) {
	g.setColor(Color.red);
        //frame
      //  g.drawLine(100,100,100,380);//left line
	//g.drawLine(100,100,380,100);//top line
       /// g.drawLine(100,380,380,380);//bottom line
       // g.drawLine(380,100,380,380);//right line
	
        //H
        g.drawLine(100,100,100,200);
        g.drawLine(150,100,150,200);
        g.drawLine(100,150,150,150);
        
        //E
        g.drawLine(160,100,160,200);
        g.drawLine(160,100,210,100);
        g.drawLine(160,150,210,150);
        g.drawLine(160,200,210,200);
        
        //L
        g.drawLine(215,100,215,200);
        g.drawLine(215,200,265,200);
        //L
        g.drawLine(265,100,265,200);
        g.drawLine(265,200,315,200);
       
        //O
        g.drawLine(315,100,365,100);
        g.drawLine(315,200,365,200);
        g.drawLine(315,100,315,200);
        g.drawLine(365,100,365,200);
        
        //W
        g.drawLine(50,300,50,400);
        g.drawLine(100,300,100,400);
        g.drawLine(75,300,75,400);
        g.drawLine(50,400,100,400);
       // g.drawLine(75,300,75,50);
       // g.drawLine(50,300,75,400);
       // g.drawLine(75,300,75,400);
        
       // g.drawLine(75,300,300,400);
       // g.drawLine(75,300,75,100); fix!
       // g.drawLine(100,300,75,400);
        //O
        g.drawLine(110,300,160,300);
        g.drawLine(110,400,160,400);
        g.drawLine(110,300,110,400);
        g.drawLine(160,300,160,400);
        //R
        g.drawLine(170,300,170,400);
        g.drawLine(170,300,220,300);
        g.drawLine(220,300, 220,340);
        g.drawLine(220,340, 170,340);
        g.drawLine(170,340,220,400);
        //L
        g.drawLine(230,300,230,400);
        g.drawLine(230,400, 280, 400);
        //D
        g.drawLine(300,300,300,400);
        
        
        //!
        g.drawLine(365,300,365,380);
        g.drawLine(365,390,365,400);
        
    }
    
}
